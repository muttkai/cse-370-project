<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

    <style type="text/css">
        body {
            background-color: #000; /* Black background */
            color: #fff;
            font-family: 'Roboto', sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }

        .login-container {
            background-color: #1c1c1c;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.7);
            width: 100%;
            max-width: 400px;
            box-sizing: border-box;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .login-container input[type="text"],
        .login-container input[type="password"] {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            background-color: #333;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 14px;
            box-sizing: border-box;
        }

        .login-container input[type="submit"] {
            width: 100%;
            padding: 15px;
            background-color: #ff3300;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .login-container input[type="submit"]:hover {
            background-color: #ff5722;
        }

        .login-container .cta {
            text-align: center;
            margin-top: 20px;
        }

        .login-container .cta a {
            color: #ff3300;
            text-decoration: none;
            font-weight: 500;
        }

        .login-container .cta a:hover {
            color: #ff5722;
        }

        .message {
            text-align: center;
            color: #f44336;
            margin-top: 10px;
        }

        .success {
            color: #4caf50;
        }
    </style>
</head>

<body>

    <?php
    include("connection/dbconnect.php"); // connecting to database
    error_reporting(0);
    session_start();
    if (isset($_POST['submit']))   // if button is submit
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        if (!empty($_POST["submit"])) {
            $query = "SELECT * FROM users U INNER JOIN customer C ON U.U_ID = C.Customer_ID WHERE U.Username= '$username' AND U.Pass='$password'";
            $result = mysqli_query($db, $query);
            $row = mysqli_fetch_array($result);
            if (is_array($row)) // if matching record in array and if everything is right
            {
                $_SESSION["user_id"] = $row["U_ID"]; // storing user_id into temp session
                header("refresh:1;url=index.php"); // redirects to index.php
            } else {
                $message = "Invalid Username or Password!";
                header("location:login.php");
            }
        }
    }
    ?>

    <div class="login-container">
        <h2>Login</h2>
        <span class="message"><?php echo $message; ?></span>
        <span class="success"><?php echo $success; ?></span>
        <form action="" method="post">
            <input type="text" name="username" placeholder="Username" required />
            <input type="password" name="password" placeholder="Password" required />
            <input type="submit" name="submit" value="Login" />
        </form>
        <div class="cta">Not Registered? <a href="registration.php">Create an account</a></div>
    </div>

</body>

</html>
