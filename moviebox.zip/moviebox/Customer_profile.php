<!DOCTYPE html>
<html lang="en">
<?php
include("connection/dbconnect.php");  //include connection file
error_reporting(0);  // using to hide undefine undex errors
session_start(); //start temp session until logout/browser closed


?>
<?php
if (isset($_POST['submit'])) {

    $userId = $_SESSION['user_id'];

    $newPass = $_POST['newPass'];
    $newPhone = $_POST['newPhone'];

    if (!empty($newPass) && !empty($newPhone)) {

        // Update both password and phone
        $sql = "UPDATE users SET Pass='$newPass' WHERE U_ID=$userId";
        mysqli_query($db, $sql);

        $sql = "UPDATE customer SET Phone_Number='$newPhone' WHERE Customer_ID=$userId";
        mysqli_query($db, $sql);
        header("Location: index.php");
    } else if (!empty($newPass)) {

        // Update only password
        $message = "Password Updated";
        $sql = "UPDATE users SET Pass='$newPass' WHERE U_ID=$userId";
        mysqli_query($db, $sql);
        
        header("Location: index.php");
    } else if (!empty($newPhone)) {

        // Update only phone 
        $message = "Phone Number Updated";
        $sql = "UPDATE customer SET Phone_Number='$newPhone' WHERE Customer_ID=$userId";
        mysqli_query($db, $sql);

         header("Location: index.php");
    } else {
        $message = "No data to update";
        header("Location: Customer_profile.php");
    }
}
?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Your Profile</title>
    <style>
        body {
            background-color: #000000;

        }

        input {
            background-color: white;
            color: black;
            border: 0;
        }

        .navbar {
            background-color: #0f0e0e;
        }

        .navbar,
        .nav-link,
        .navbar-brand {
            color: white;
        }

        .c1 {
            color: white;
        }

        .rounded-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
        }

        .form-group-2 {
            margin-left: 1.75in;
            text-align: left;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg">

        <div class="container-fluid">

            <a class="navbar-brand" href="index.php" style="height: 50px; width: 150px; font-weight: bold;">MovieBox</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                <!-- Empty div to push menu items to right -->
                <div class="me-auto"></div>

                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="index.php" style="color:white;font-weight:bold;">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="available_movies.php" style="color:white;font-weight:bold;">Movies</a>
                    </li>

                    <?php
                    if (empty($_SESSION["user_id"])) {
                        echo '<li class="nav-item"><a href="login.php" class="nav-link active"style="color:white;font-weight:bold;">Login</a> </li>
                      <li class="nav-item"><a href="registration.php" class="nav-link active"style="color:white;font-weight:bold;">Signup</a> </li>';
                    } else {
                        echo '<li class="nav-item"><a href="Customer_profile.php" class="nav-link active"style="color:white;font-weight:bold;">Profile</a> </li>';
                        echo '<li class="nav-item"><a href="logout.php" class="nav-link active"style="color:white;font-weight:bold;">Logout</a> </li>';
                    }
                    ?>
                </ul>


            </div>

        </div>

    </nav>

    <br /><br /><br />
    <?php
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM users U inner join customer C on U.U_ID=C.Customer_ID where U.U_ID=$user_id";

    $result = mysqli_query($db, $sql);

    $user_data = mysqli_fetch_assoc($result);;
    ?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 bg-dark text-white p-5 rounded shadow-sm">
            <section class="text-center mb-4">
                <!-- <img src="img/blank-profile-picture.png" class="rounded-circle img-fluid" alt="Profile Picture" width="120" height="120"> -->
                <h2 class="mt-3">Welcome, <?php echo $user_data['Customer_Name']; ?></h2>
            </section>
            
            <form action="" method="post">
                <div class="form-group mb-4">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" id="username" value="<?php echo $user_data['Username']; ?>" disabled>
                </div>

                <div class="form-group mb-4">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" value="<?php echo $user_data['Customer_Name']; ?>" disabled>
                </div>

                <div class="form-group mb-4">
                    <label for="email">Email Address</label>
                    <input type="email" class="form-control" id="email" value="<?php echo $user_data['Email']; ?>" disabled>
                </div>

                <div class="form-group mb-4">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" value="<?php echo $user_data['Pass']; ?>" disabled>
                </div>

                <div class="form-group mb-4">
                    <label for="phone">Phone Number</label>
                    <input type="text" class="form-control" id="phone" value="<?php echo $user_data['Phone_number']; ?>" disabled>
                </div>

                <div class="text-center mb-4">
                    <button type="button" id="update-prof-btn" class="btn btn-outline-light btn-lg">Update Profile</button>
                </div>

                <div id="prof-input" class="text-center" style="display:none;">
                    <div class="form-group mb-4">
                        <label for="newPass">New Password</label>
                        <input type="password" class="form-control" name="newPass" id="newPass">
                    </div>

                    <div class="form-group mb-4">
                        <label for="newPhone">New Phone</label>
                        <input type="text" class="form-control" name="newPhone" id="newPhone">
                    </div>

                    <input type="submit" value="Save Changes" name="submit" class="btn btn-primary btn-lg">
                </div>
            </form>
        </div>
    </div>
</div>

    <script>
        const updateBtn = document.getElementById('update-prof-btn');
        const profInput = document.getElementById('prof-input');

        updateBtn.addEventListener('click', () => {
            profInput.style.display = 'block';
        });
    </script>


</body>

</html>