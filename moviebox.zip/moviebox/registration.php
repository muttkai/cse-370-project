<!DOCTYPE html>
<html lang="en">
<?php
session_start();
error_reporting(0);
include("connection/dbconnect.php"); //connection
if (isset($_POST['submit'])) {
    if (
        empty($_POST['username']) ||
        empty($_POST['fname']) ||
        empty($_POST['email']) ||
        empty($_POST['phone']) ||
        empty($_POST['password']) ||
        empty($_POST['cpassword'])
    ) {
        $message = "All fields must be Required!";
    } else {
        //checking if username and email already exists in database
        $check_username = mysqli_query($db, "SELECT Username FROM users WHERE Username = '" . $_POST['username'] . "' ");
        $check_email = mysqli_query($db, "SELECT Email FROM users WHERE Email = '" . $_POST['email'] . "' ");

        if ($_POST['password'] != $_POST['cpassword']) {
            $message = "Password not match";
        } elseif (strlen($_POST['password']) < 6) {
            $message = "Password Must be >=6";
        } elseif (strlen($_POST['phone']) < 10) {
            $message = "Invalid phone number!";
        } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $message = "Invalid email address, please type a valid email!";
        } elseif (mysqli_num_rows($check_username) > 0) {
            $message = 'Username Already exists!';
        } elseif (mysqli_num_rows($check_email) > 0) {
            $message = 'Email Already exists!';
        } else {
            //inserting values into db
            $sql = "INSERT INTO users(Username, Email, Pass) 
                    VALUES('" . $_POST['username'] . "', 
                           '" . $_POST['email'] . "',
                           '" . $_POST['password'] . "')";
            mysqli_query($db, $sql);
            //Retrieving id of inserted user
            $user_id = mysqli_insert_id($db);
            $sql = "INSERT INTO customer(Customer_Name, Phone_Number, Customer_ID)  
                    VALUES('" . $_POST['fname'] . "',
                           '" . $_POST['phone'] . "', 
                           $user_id)";
            mysqli_query($db, $sql);

            $success = "Account Created successfully! <p>You will be redirected in <span id='counter'>5</span> second(s).</p>
                        <script type='text/javascript'>
                        function countdown() {
                            var i = document.getElementById('counter');
                            if (parseInt(i.innerHTML) <= 0) {
                                location.href = 'login.php';
                            }
                            i.innerHTML = parseInt(i.innerHTML) - 1;
                        }
                        setInterval(function() { countdown(); }, 1000);
                        </script>";

            header("refresh:5;url=login.php"); // After successful insertion redirects to login page
        }
    }
}
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="#">
    <title>Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animsition.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <style>
        body {
            background-color: #000;
            color: #fff;
            font-family: 'Roboto', sans-serif;
        }

        .registration-container {
            background-color: #1c1c1c;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.7);
            width: 100%;
            max-width: 600px;
            margin: 50px auto;
            box-sizing: border-box;
        }

        .registration-container h2 {
            text-align: center;
            margin-bottom: 20px;
            font-weight: 500;
            color: #fff; /* Set the title color to white */
        }

        .registration-container input[type="text"],
        .registration-container input[type="password"] {
            width: 100%;
            padding: 15px;
            margin: 10px 0;
            background-color: #333;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 14px;
            box-sizing: border-box;
        }

        .registration-container input[type="submit"] {
            width: 100%;
            padding: 15px;
            background-color: #ff3300;
            border: none;
            border-radius: 5px;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        .registration-container input[type="submit"]:hover {
            background-color: #ff5722;
        }

        .message {
            text-align: center;
            color: #f44336;
            margin-top: 10px;
        }

        .success {
            color: #4caf50;
        }

        .navbar {
            background-color: #0f0e0e;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <header id="header" class="header-scroll top-header headroom">
        <nav class="navbar navbar-dark">
            <div class="container-fluid">
                <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
                <a class="navbar-brand" href="index.php" style="height: 50px; width: 150px; font-weight: bold;">MovieBox</a>
                <div class="collapse navbar-toggleable-md float-lg-right" id="mainNavbarCollapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"> <a class="nav-link active" href="index.php">Home <span class="sr-only">(current)</span></a> </li>
                        <li class="nav-item"> <a class="nav-link active" href="available_movies.php">Movies <span class="sr-only"></span></a> </li>
                        <?php
                        if (empty($_SESSION["user_id"])) {
                            echo '<li class="nav-item"><a href="login.php" class="nav-link active">login</a> </li>
                                  <li class="nav-item"><a href="registration.php" class="nav-link active">signup</a> </li>';
                        } else {
                            echo '<li class="nav-item"><a href="Ticket_Purchase.php" class="nav-link active">Buy Ticket</a> </li>';
                            echo '<li class="nav-item"><a href="Customer_profile.php" class="nav-link active">Profile</a> </li>';
                            echo '<li class="nav-item"><a href="logout.php" class="nav-link active">logout</a> </li>';
                        }
                        ?>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="page-wrapper">
        <div class="breadcrumb">
            <div class="container">
                <ul>
                    <li>
                        <a href="#" class="active">
                            <span style="color:red;"><?php echo $message; ?></span>
                            <span style="color:green;"><?php echo $success; ?></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <section class="contact-page inner-page" style="color:#22404A;">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="registration-container">
                            <h2>Register</h2>
                            <form action="" method="post">
                                <input type="text" name="username" placeholder="User Name" required />
                                <input type="text" name="fname" placeholder="Full Name" required />
                                <input type="text" name="email" placeholder="Email Address" required />
                                <input type="text" name="phone" placeholder="Phone Number" required />
                                <input type="password" name="password" placeholder="Password" required />
                                <input type="password" name="cpassword" placeholder="Repeat Password" required />
                                <input type="submit" value="Register" name="submit" />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script src="js/jquery.min.js"></script>
    <script src="js/tether.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/animsition.min.js"></script>
    <script src="js/bootstrap-slider.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/validator.js"></script>
    <script src="js/scripts.js"></script>
</body>

</html>
