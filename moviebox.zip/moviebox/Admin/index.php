<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/login.css">

      <style type="text/css">
    body {
        background-color: #121212;
        font-family: 'Roboto', sans-serif;
        color: #e0e0e0;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    .container {
        text-align: center;
        margin-bottom: 20px;
    }

    .info h1 {
        font-size: 2.5em;
        margin: 0;
    }

    .info span {
        font-size: 1.2em;
        color: #ff6600;
    }

    .form {
        background-color: #1e1e1e;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        width: 300px;
        text-align: center;
    }

    input[type="text"],
    input[type="password"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: none;
        border-radius: 4px;
        background-color: #333;
        color: #e0e0e0;
        font-size: 1em;
        transition: background-color 0.3s;
    }

    input[type="text"]:focus,
    input[type="password"]:focus {
        background-color: #444;
        outline: none;
    }

    input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin: 10px 0;
        border: none;
        border-radius: 4px;
        background-color: #ff3300;
        color: #fff;
        font-size: 1em;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    input[type="submit"]:hover {
        background-color: #ff6600;
    }

    .message {
        margin-top: 15px;
        font-size: 0.9em;
        color: #bbb;
    }

    .message a {
        color: #ff6600;
        text-decoration: none;
    }

    .message a:hover {
        text-decoration: underline;
    }
</style>


</head>

<body>
<?php
include("../connection/dbconnect.php");
error_reporting(0);
session_start();
if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if(!empty($_POST["submit"])) 
     {
	$loginquery ="SELECT * FROM users U INNER JOIN admins A ON U.U_ID = A.Admin_ID WHERE U.Username= '$username' AND U.Pass='$password'";
	$result=mysqli_query($db, $loginquery);
	$row=mysqli_fetch_array($result);
	
	                        if(is_array($row))
								{
                                    	$_SESSION["adm_id"] = $row['Admin_ID'];
                                        $success="Login Successful";
										 header("refresh:1;url=admin_profile.php");
	                            } 
							else
							    {
                                      	$message = "Invalid Username or Password!";
                                }
	 }	
}
?>

  
<div class="container">
  <div class="info">
    <h1>Administration </h1><span> login Account</span>
  </div>
</div>
<div class="form">
  <span style="color:red;"><?php echo $message; ?></span>
   <span style="color:green;"><?php echo $success; ?></span>
  <form class="login-form" action="index.php" method="post">
    <input type="text" placeholder="username" name="username"/>
    <input type="password" placeholder="password" name="password"/>
    <input type="submit"  name="submit" value="login" />
  </form>
  
</div>

  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
  <script src='js/index.js'></script>
  

    



</body>

</html>