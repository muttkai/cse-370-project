<!DOCTYPE html>
<html lang="en">
<?php
include("../connection/dbconnect.php");  // Include connection file
error_reporting(0);  // Using to hide undefined index errors
session_start(); // Start temp session until logout/browser closed
if (!isset($_SESSION["adm_id"])) {
    // Redirect to the login page
    header("Location: index.php"); // 
}


?>

<head>
    <title>Customer Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body {
            background-color: #000;  /* Set background to black */
            color: #fff;  /* Set font color to white */
        }

        .navbar {
            background-color: #0f0e0e;
        }

        .navbar,
        .nav-link,
        .navbar-brand {
            color: white;
        }

        .navbar a:hover,
        .dropdown:hover .dropbtn {
            background-color: red;
        }

        .c1 {
            color: white;
        }

        .container {
            margin-left: 5%;
            margin-right: 0%;
        }

        section {
            background-color: #a8dadc;  /* Keep section background as it is */
            color: black;  /* Set text color in section to black for readability */
        }

        .rounded-circle {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
        }

        table {
            border-spacing: 0;
            border-collapse: collapse;
            color: white;  /* Table text color */
        }

        table,
        th,
        td {
            border: 1px solid white;  /* Change border color to white */
        }

        th,
        td {
            padding: 8px 16px;
        }

        .deleteBtn {
            background-color: red;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 8px 12px;
        }
    </style>

</head>

<body>
    <nav class="navbar navbar-expand-sm ">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="me-auto"></div>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin_profile.php"><b><i>Home</i></b></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><br /><br />

    <center>
        <section style="background-color:#000000;">
        <h2 style="color: white;"><i>Customer Info</i></h2><br />
            <table>
                <thead>
                    <tr>
                        <th>Customer ID</th>
                        <th>Username</th>
                        <th>Customer Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th> Action </th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT u.*,c.Customer_Name,C.Phone_number FROM users u INNER JOIN customer c on U.U_ID=c.Customer_ID;";
                    $result = mysqli_query($db, $sql);
                    if ($result) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>"; ?>
                            <form method="POST" action="">
                                <input type="hidden" name="Cust_ID" value="<?php echo $row['U_ID']; ?>">
                                <?php
                                echo "<td>" . $row['U_ID'] . "</td>";
                                echo "<td>" . $row['Username'] . "</td>";
                                echo "<td>" . $row['Customer_Name'] . "</td>";
                                echo "<td>" . $row['Email'] . "</td>";
                                echo "<td>" . $row['Phone_number'] . "</td>";

                                ?>
                                <td>
                                    <button class="deleteBtn" name="delete" style=' background-color: red;color: white;border: none; border-radius: 4px;padding: 8px 12px; '>Delete</button>
                            </form>
                            </td>
                    <?php
                            if (isset($_POST['delete']) && $_POST['Cust_ID'] == $row['U_ID']) {
                                $sql = "DELETE FROM users WHERE U_ID = '" . $_POST['Cust_ID'] . "'";
                                mysqli_query($db, $sql);
                                header("Location: allmovies.php");
                                exit();
                            }
                        }
                        echo "</tr>";
                    }
                    ?>



                </tbody>
            </table>

        </section>
    </center>

</body>

</html>