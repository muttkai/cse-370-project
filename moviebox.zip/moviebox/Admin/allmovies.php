<!DOCTYPE html>
<html lang="en">
<?php
include("../connection/dbconnect.php");  // Include connection file
error_reporting(0);  // Using to hide undefined index errors
session_start(); // Start temp session until logout/browser closed
if (!isset($_SESSION["adm_id"])) {
    // Redirect to the login page
    header("Location: index.php"); // 
}

?>


<head>
    <title>All Movies</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>
        body {
            background-color: #000000;
            color: white; /* Set default text color to white */
        }

        .navbar {
            background-color: #0f0e0e;
            color: white;
        }

        .navbar a {
            color: white; /* Ensure navbar links are white */
        }

        .navbar a:hover,
        .dropdown:hover .dropbtn {
            background-color: red; /* Keep the hover effect */
        }

        table, th, td {
            border: 1px solid white;
            color: white; /* Set table text color to white */
        }

        th, td {
            padding: 8px 16px;
        }

    </style>
</head>

<body>
    <nav class="navbar navbar-expand-sm ">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="me-auto"></div>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="admin_profile.php"><b><i>Home</i></b></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav><br /><br />
    <div class="text-end" style="background-color:black; opacity:0.75; color:1;">
        <section class="d-flex justify-content-end">
            <a class="nav-link me-3" href="?filter=all" style="color:white;"><b><i><u>All Movies</u></i></b></a>
            <a class="nav-link me-3" href="?filter=new" style="color:white;"><b><i><u>New Movies</u></i></b></a>
            <a class="nav-link" href="?filter=old" style="color:white;"><b><i><u>Old Movies</u></i></b></a>
        </section>
    </div>
    <center>
        <section style="background-color:#000000;">
            <h2><i>Movies</i></h2><br />
            <table>
                <thead>
                    <tr>
                        <th>Index</th>
                        <th>Title</th>
                        <th>Trailer</th>
                        <th>Year</th>
                        <th>Runtime</th>
                        <th>Genres</th>
                        <th>Casts</th>
                        <!-- <th>Prequel</th> -->
                        <?php
                        $movieType = isset($_GET['filter']) ? $_GET['filter'] : "";
                        if ($movieType == "old") {
                            echo "<th>Stream Link</th>";
                        }
                        if (($movieType == "all") || ($movieType == "")) {
                            echo "<th>Action</th>";
                        } else {
                        }
                        ?>


                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($movieType == "new") {
                        $sql = "SELECT M.*, GROUP_CONCAT(DISTINCT G.Genre) AS MovieGenres, GROUP_CONCAT(DISTINCT C.Cast) AS MovieCasts  FROM movies M  INNER JOIN new_movies N on M.Movie_index=N.Movie_index LEFT JOIN movie_genre G 
                    ON M.Movie_index = G.Movie_index  LEFT JOIN movie_castings C ON M.Movie_index = C.Movie_index GROUP BY M.Movie_index";
                        $result = mysqli_query($db, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['Movie_index'] . "</td>";
                                echo "<td>" . $row['Title'] . "</td>";
                                echo "<td>" . $row['Trailer_link'] . "</td>";
                                echo "<td>" . $row['Release_Date'] . "</td>";
                                echo "<td>" . $row['Watch_Time'] . 'mins' . "</td>";
                                echo "<td>" . $row['MovieGenres'] . "</td>";
                                echo "<td>" . $row['MovieCasts'] . "</td>";

                                // echo "<td>" . $row['Pre_sequel'] . "</td>";
                            }
                            echo "</tr>";
                        }
                    } ?>



                    <?php
                    if ($movieType == "old") {
                        $sql = "SELECT M.*, GROUP_CONCAT(DISTINCT G.Genre) AS MovieGenres, GROUP_CONCAT(DISTINCT C.Cast) AS MovieCasts,O.Stream_link  FROM movies M  INNER JOIN old_movies O on M.Movie_index=O.Movie_index LEFT JOIN movie_genre G 
                    ON M.Movie_index = G.Movie_index  LEFT JOIN movie_castings C ON M.Movie_index = C.Movie_index GROUP BY M.Movie_index";
                        $result = mysqli_query($db, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['Movie_index'] . "</td>";
                                echo "<td>" . $row['Title'] . "</td>";
                                echo "<td>" . $row['Trailer_link'] . "</td>";
                                echo "<td>" . $row['Release_Date'] . "</td>";
                                echo "<td>" . $row['Watch_Time'] . 'mins' . "</td>";
                                echo "<td>" . $row['MovieGenres'] . "</td>";
                                echo "<td>" . $row['MovieCasts'] . "</td>";

                                // echo "<td>" . $row['Pre_sequel'] . "</td>";
                                echo "<td>" . $row['Stream_link'] . "</td>";
                            }
                            echo "</tr>";
                        }
                    }
                    if ($movieType == "all") {
                        $sql = "SELECT M.*, GROUP_CONCAT(DISTINCT G.Genre) AS MovieGenres, GROUP_CONCAT(DISTINCT C.Cast) AS MovieCasts  FROM movies M  LEFT JOIN movie_genre G 
                    ON M.Movie_index = G.Movie_index  LEFT JOIN movie_castings C ON M.Movie_index = C.Movie_index GROUP BY M.Movie_index";
                        $result = mysqli_query($db, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>"; ?>
                                <form method="POST" action="">
                                    <input type="hidden" name="movieIndex" value="<?php echo $row['Movie_index']; ?>">
                                    <?php echo "<td>" . $row['Movie_index'] . "</td>";
                                    echo "<td>" . $row['Title'] . "</td>";
                                    echo "<td>" . $row['Trailer_link'] . "</td>";
                                    echo "<td>" . $row['Release_Date'] . "</td>";
                                    echo "<td>" . $row['Watch_Time'] . 'mins' . "</td>";
                                    echo "<td>" . $row['MovieGenres'] . "</td>";
                                    echo "<td>" . $row['MovieCasts'] . "</td>";

                                    // echo "<td>" . $row['Pre_sequel'] . "</td>";
                                    ?>

                                    <td>
                                    
                                    <button class="deleteBtn" name="delete" style=' background-color: red;color: white;border: none; border-radius: 4px;padding: 8px 12px; '>Delete</button>
                                        </form>
                                        <a href="edit_details.php?id=<?php echo $row['Movie_index']; ?>"target="_blank"><button style=' background-color: green;color: white;border: none; border-radius: 4px;padding: 8px 12px; '>Update</button></a>
                                    </td>
                                
                            <?php
                            if(isset($_POST['delete']) && $_POST['movieIndex'] == $row['Movie_index']){
                                $sql = "DELETE FROM movies WHERE Movie_index = '" . $_POST['movieIndex'] . "'";
                                mysqli_query($db,$sql);
                                header("Location: allmovies.php");
                                exit();
                            }
                            
                    
                                }
                            echo "</tr>";
                        }
                    }
                    if ($movieType == "") {
                        $sql = "SELECT M.*, GROUP_CONCAT(DISTINCT G.Genre) AS MovieGenres, GROUP_CONCAT(DISTINCT C.Cast) AS MovieCasts  FROM movies M  LEFT JOIN movie_genre G 
                    ON M.Movie_index = G.Movie_index  LEFT JOIN movie_castings C ON M.Movie_index = C.Movie_index GROUP BY M.Movie_index";
                        $result = mysqli_query($db, $sql);

                        if ($result) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>"; ?>
                                <form method="POST" action="">
                                    <input type="hidden" name="movieIndex" value="<?php echo $row['Movie_index']; ?>">
                                    <?php
                                    echo "<td>" . $row['Movie_index'] . "</td>";
                                    echo "<td>" . $row['Title'] . "</td>";
                                    echo "<td>" . $row['Trailer_link'] . "</td>";
                                    echo "<td>" . $row['Release_Date'] . "</td>";
                                    echo "<td>" . $row['Watch_Time'] . 'mins' . "</td>";
                                    echo "<td>" . $row['MovieGenres'] . "</td>";
                                    echo "<td>" . $row['MovieCasts'] . "</td>";

                                    // echo "<td>" . $row['Pre_sequel'] . "</td>";
                                    ?>

                                    <td>
                                    <button class="deleteBtn" name="delete" style=' background-color: red;color: white;border: none; border-radius: 4px;padding: 8px 12px; '>Delete</button>
                            </form>
                            <a href="edit_details.php?id=<?php echo $row['Movie_index']; ?>"target="_blank"><button style=' background-color: green;color: white;border: none; border-radius: 4px;padding: 8px 12px; '>Update</button></a>
                                    </td>
            
                                
                        <?php
                        if(isset($_POST['delete']) && $_POST['movieIndex'] == $row['Movie_index']){
                            $sql = "DELETE FROM movies WHERE Movie_index = '" . $_POST['movieIndex'] . "'";
                            mysqli_query($db,$sql);
                            header("Location: allmovies.php");
                            exit();
                        }
                        
                
                            }
                            echo "</tr>";
                        }
                    } ?>

                        <!-- Update Movie Modal -->




                </tbody>
            </table>

        </section>
    </center>


</body>

</html>